package com.quickhire.QuickHire;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // Allow CORS for the specific origin (your frontend's URL)
        registry.addMapping("/api/**")
                .allowedOrigins("http://localhost:8080") // Replace with your frontend URL if different
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Specify allowed methods
                .allowCredentials(true); // Allow cookies if needed
    }
}
